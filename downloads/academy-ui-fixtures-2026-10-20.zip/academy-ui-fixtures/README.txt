Academy UI practice fixtures - October 20, 2026

These are fictional static exercise pages, not a replacement Windows kit.
The online Class Three examples already use the hosted pages and need no installation.

For a LOCAL workshop that uses /ui-components.html or /ui-advanced.html:
1. Extract this archive into a NEW folder. Do not extract over saved work.
2. Open your editable practice-app project (the folder containing package.json).
3. Create public if absent. Copy ONLY the supplied public files into it.
   If a same-named file already exists, back it up and ask your instructor before replacing it.
   Keep your src, tests, configuration, package files and other public files.
4. In that practice-app terminal, run: npm run build
5. In a second terminal in practice-app, run: npm start
6. Open http://127.0.0.1:4173/ui-components.html or /ui-advanced.html.
7. Run the workshop command in its own terminal. Stop your server with Ctrl+C.

The advanced order and GraphQL exercise endpoints have NO backend. The tests
explicitly intercept them. A manual request without a test stub will show an error.
Keep the pinned toolchain. No paid cloud account or real customer data is required.
